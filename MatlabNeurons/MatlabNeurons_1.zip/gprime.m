function y=gprime(x)
y = ((exp(-x))./((1+exp(-x)).^2));