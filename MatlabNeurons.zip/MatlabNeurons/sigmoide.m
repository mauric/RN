function y=sigmoide(x)
y = 1 ./ (1 + exp(-x));
